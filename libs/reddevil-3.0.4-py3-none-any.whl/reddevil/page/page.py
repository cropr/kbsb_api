# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import logging

log = logging.getLogger(__name__)

import uuid
from datetime import datetime, timezone, date
from slugify import slugify
from typing import List, cast
from reddevil.core import (
    encode_model,
)
from reddevil.page.md_page import (
    PageIn,
    PageList,
    PageUpdate,
    Page,
    DbPage,
)

log = logging.getLogger(__file__)


async def createPage(d: PageIn) -> str:
    """
    create a new Page returning its id
    """
    tsnow = datetime.now(tz=timezone.utc)
    dd = d.dict()
    dd["layout"] = "default"
    dd["creationtime"] = tsnow
    dd["enabled"] = False
    dd["expirationdate"] = ""
    dd["id"] = str(uuid.uuid4())
    dd["body"] = {
        "default": dict(value=""),
        d.locale: dict(value=""),
    }
    dd["intro"] = {
        "default": dict(value=""),
        d.locale: dict(value=""),
    }
    dd["title"] = {
        "default": dict(value=d.name),
        d.locale: dict(value=d.name),
    }
    dd["languages"] = [d.locale]
    dd["modificationtime"] = tsnow
    dd["owner"] = ""
    dd["publicationdate"] = ""
    dd["slug"] = slugify(d.name)
    return await DbPage.add(dd)


async def deletePage(id: str) -> None:
    await DbPage.delete(id)


async def getPage(id: str, options: dict = {}) -> Page:
    """
    get the page
    """
    validator = options.pop("_class", Page)
    filter = dict(id=id, **options)
    pdict = await DbPage.find_single(filter)
    # pdict["active"] = isactive(pdict)
    return cast(Page, encode_model(pdict, validator))


async def getPageBySlug(slug: str, options: dict = {}) -> Page:
    """
    get the page
    """
    validator = options.pop("_class", Page)
    filter = dict(slug=slug, **options)
    pdict = await DbPage.find_single(filter)
    # pdict["active"] = isactive(pdict)
    return cast(Page, encode_model(pdict, validator))


async def getPages(options: dict = {}) -> PageList:
    """
    get all the pages
    """
    validator = options.pop("_class", Page)
    docs = await DbPage.find_multiple(options)
    pages = [encode_model(pdict, validator) for pdict in docs]
    return PageList(items=pages)


async def updatePage(id: str, d: PageUpdate) -> Page:
    """
    update a page
    """
    dd = d.dict(exclude_unset=True)
    pdict = await DbPage.update(id, dd)
    return cast(Page, encode_model(pdict, Page))


async def getActiveArticles(token: str = None) -> PageList:
    """
    get all the pages
    """
    dl = await DbPage.find_multiple(
        {
            "doctype": "article",
            "enabled": True,
            "_fieldlist": [
                "creationtime",
                "enabled",
                "expirationdate",
                "name",
                "modificationtime",
                "publicationdate",
                "slug",
                "id",
                "body",
                "intro",
                "title",
            ],
            "publicationdate": {"$ne": ""},
        }
    )
    ap = [x for x in dl if isactive(x)]
    ap = sorted(ap, key=lambda x: x["publicationdate"], reverse=True)
    return PageList(items=ap)


def isactive(dd: dict) -> bool:
    """
    checks whether a page is active
    """
    if not dd.get("enabled"):
        return False
    p = dd["publicationdate"]
    e = dd["expirationdate"]
    published = p and (date.fromisoformat(p) <= date.today())
    expired = e and (date.fromisoformat(e) < date.today())
    return bool(published and not expired)
