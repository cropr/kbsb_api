# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2020

# all models in the service level exposed to the API
# we are using pydantic as tool

import logging

import asyncio
from datetime import datetime, date
from typing import Dict, Any, List, Optional, Type, Union
from enum import Enum
from pydantic import BaseModel, Field, validator
from reddevil.core import get_mongodb, DbBase, DocumentType, ListType
from pymongo import ReturnDocument

log = logging.getLogger(__name__)


class Page_:
    """
    a Page as written in database
    """

    body: Dict[str, Any]
    doctype: str
    enabled: bool
    expirationdate: str  # format yyyy-mm-dd
    intro: Dict[str, Any]
    languages: List[str]
    layout: str
    name: str
    owner: str
    publicationdate: str  # format yyyy-mm-dd
    slug: str
    title: Dict[str, Any]
    _id: str
    _version: int
    _documenttype: str
    _creationtime: datetime
    _modificationtime: datetime


class Page(DocumentType):
    """
    as a default all fields in Page are Optional so we can work on raw database documents
    """

    body: Optional[Dict[str, Any]] = None
    doctype: Optional[str] = None
    enabled: Optional[bool] = None
    expirationdate: Optional[str] = None  # format yyyy-mm-dd
    intro: Optional[Dict[str, Any]] = None
    id: Optional[str] = None
    languages: Optional[List[str]] = None
    layout: Optional[str] = None
    name: Optional[str] = None
    owner: Optional[str] = None
    publicationdate: Optional[str] = None  # format yyyy-mm-dd
    slug: Optional[str] = None
    title: Optional[Dict[str, Any]] = None
    _version: Optional[int] = None
    _documenttype: Optional[str] = None
    _creationtime: Optional[datetime] = None
    _modificationtime: Optional[datetime] = None
    active: bool = None

    @validator("active", always=True)
    def isactive(cls, v, values, **kwargs):
        if not values["enabled"]:
            return False
        p = values["publicationdate"]
        e = values["expirationdate"]
        published = p and (date.fromisoformat(p) <= date.today())
        expired = e and (date.fromisoformat(e) < date.today())
        return bool(published and not expired)


class PageIn(BaseModel):
    """
    validator for new pages
    """

    doctype: str  # 'normal-page', 'article', 'app-page'
    locale: str
    name: str


class PageList(ListType):
    pages: List[Page] = Field(alias="items")


class PageUpdate(BaseModel):
    """
    validator for Page updates
    """

    body: Optional[Dict[str, Any]]
    doctype: Optional[str]
    enabled: Optional[bool]
    expirationdate: Optional[str]  # format yyyy-mm-dd
    intro: Optional[Dict[str, Any]] = None
    languages: Optional[List[str]]
    name: Optional[str]
    owner: Optional[str]
    publicationdate: Optional[str]  # format yyyy-mm-dd
    slug: Optional[str]
    title: Optional[Dict[str, Any]] = None


class PageI18nFields:

    # the fields for this class are for documentation purposes
    # they are not used in the code

    body: str
    intro: str
    title: str


class DbPage(DbBase):
    COLLECTION = "rd_page"
    DOCUMENTTYPE = "Page"
    SIMPLEFIELDS = [
        "body",
        "_creationtime",
        "doctype",
        "enabled",
        "expirationdate",
        "intro",
        "languages",
        "name",
        "_modificationtime",
        "publicationdate",
        "slug",
        "title",
        "_version",
    ]
    VERSION = 2
    FORCEUPGRADE = True
    IDGENERATOR = "uuid"
    DT = Page
    IT = PageIn
    UT = PageUpdate
    LT = PageList

    @classmethod
    async def upgrade(
        cls, doc: dict, projfields: Optional[dict], from_version: int = 1
    ) -> dict:
        """
        upgrade the document to the current version
        """
        db = await get_mongodb()
        coll = db[cls.COLLECTION]
        if from_version == 1:
            # add _documenttype, _version, _modificationtime, _creationtime
            # remove creationtime, modificationtime
            docfull = await coll.find_one({"_id": doc["_id"]})
            docupgrade = await coll.find_one_and_update(
                {"_id": doc["_id"]},
                {
                    "$set": {
                        "_documenttype": cls.DOCUMENTTYPE,
                        "_version": cls.VERSION,
                        "_creationtime": docfull.get(
                            "creationtime",
                            docfull.get("created_ts", docfull.get("_creationtime")),
                        ),
                        "_modificationtime": docfull.get(
                            "modificationtime",
                            docfull.get(
                                "_modified_ts", docfull.get("_modificationtime")
                            ),
                        ),
                        "intro": docfull.get("intro", {}),
                    },
                    "$unset": {
                        "creationtime": 1,
                        "modificationtime": 1,
                    },
                },
                return_document=ReturnDocument.AFTER,
            )
            doc = await coll.find_one({"_id": doc["_id"]}, projection=projfields)
            log.info(
                f"{cls.DOCUMENTTYPE} upgraded from {from_version} tp {cls.VERSION}"
            )
            return doc
        else:
            asyncio.sleep(0)
            return doc
