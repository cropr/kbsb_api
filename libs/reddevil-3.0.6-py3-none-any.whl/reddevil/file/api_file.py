import logging

from fastapi import HTTPException, Depends
from fastapi.security import HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import List
<<<<<<<< HEAD:reddevil/api/api_file.py
from reddevil.common import (
    get_app,
    get_baseurl,
    RdException,
    bearer_schema,
)
from reddevil.service.account import validate_token
from reddevil.service.file import (
========
from reddevil.core import app, url, RdException
from reddevil.service.security import bearer_schema, validate_token
from reddevil.service.sv_file import (
>>>>>>>> pydantic-validation-inside-DbBase:reddevil/file/api_file.py
    createFile,
    deleteFile,
    getFile,
    getFileContent,
    getFiles,
    updateFile,
)
from reddevil.file.md_file import (
    FileIn,
    FileListOut,
    FileOptional,
    FileUpdate,
)

<<<<<<<< HEAD:reddevil/api/api_file.py
log = logging.getLogger(__name__)
========
log = logging.getLogger("reddevil")
>>>>>>>> pydantic-validation-inside-DbBase:reddevil/file/api_file.py

app = get_app()
url = get_baseurl()


<<<<<<<< HEAD:reddevil/api/api_file.py
@app.get("/api/v1/files", response_model=FileListOut)
========
@app.get(url + "/files", response_model=FileListOut)
>>>>>>>> pydantic-validation-inside-DbBase:reddevil/file/api_file.py
async def api_getFiles(
    reports: int = 0, auth: HTTPAuthorizationCredentials = Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        return await getFiles()
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception("failed api call get_files")
        raise HTTPException(status_code=500, detail="Internal Server Error")


<<<<<<<< HEAD:reddevil/api/api_file.py
@app.get("/api/v1/a/files", response_model=FileListOut)
========
@app.get(url + "/a/files", response_model=FileListOut)
>>>>>>>> pydantic-validation-inside-DbBase:reddevil/file/api_file.py
async def api_anon_getFiles(reports: int = 0):
    try:
        return await getFiles(dict(reports=reports))
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception("failed api call get_files")
        raise HTTPException(status_code=500, detail="Internal Server Error")


<<<<<<<< HEAD:reddevil/api/api_file.py
@app.post("/api/v1/files", response_model=str)
async def aoi_createFile(
========
@app.post(url + "/files", response_model=str)
async def api_createFile(
>>>>>>>> pydantic-validation-inside-DbBase:reddevil/file/api_file.py
    p: FileIn, auth: HTTPAuthorizationCredentials = Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        return await createFile(p)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception("failed api call create_file")
        raise HTTPException(status_code=500, detail="Internal Server Error")


<<<<<<<< HEAD:reddevil/api/api_file.py
@app.get("/api/v1/file/{id}", response_model=FileOptional)
========
@app.get(url + "/file/{id}", response_model=FileOptional)
>>>>>>>> pydantic-validation-inside-DbBase:reddevil/file/api_file.py
async def api_getFile(
    id: str, auth: HTTPAuthorizationCredentials = Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        return await getFile(id)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception("failed api call get_file")
        raise HTTPException(status_code=500, detail="Internal Server Error")


<<<<<<<< HEAD:reddevil/api/api_file.py
@app.delete("/api/v1//file/{id}")
========
@app.delete(url + "/file/{id}")
>>>>>>>> pydantic-validation-inside-DbBase:reddevil/file/api_file.py
async def api_deleteFile(
    id: str, auth: HTTPAuthorizationCredentials = Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        await deleteFile(id)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception("failed api call delete_file")
        raise HTTPException(status_code=500, detail="Internal Server Error")


<<<<<<<< HEAD:reddevil/api/api_file.py
@app.put("/api/v1/file/{id}", response_model=FileOptional)
========
@app.put(url + "/file/{id}", response_model=FileOptional)
>>>>>>>> pydantic-validation-inside-DbBase:reddevil/file/api_file.py
async def api_updateFile(
    id: str, p: FileUpdate, auth: HTTPAuthorizationCredentials = Depends(bearer_schema)
):
    try:
        await validate_token(auth)
        await updateFile(id, p)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception("failed api call update_file")
        raise HTTPException(status_code=500, detail="Internal Server Error")


<<<<<<<< HEAD:reddevil/api/api_file.py
@app.get("/api/v1/filecontent/{url}")
========
@app.get(url + "/filecontent/{url}")
>>>>>>>> pydantic-validation-inside-DbBase:reddevil/file/api_file.py
async def api_getFilecontent(
    url: str, auth: HTTPAuthorizationCredentials = Depends(bearer_schema)
):
    try:
        return await getFileContent(url)
    except RdException as e:
        raise HTTPException(status_code=e.status_code, detail=e.description)
    except:
        log.exception("failed api call get_filecontent")
        raise HTTPException(status_code=500, detail="Internal Server Error!")
