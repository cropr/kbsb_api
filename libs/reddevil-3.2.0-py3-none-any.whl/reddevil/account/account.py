# copyright Ruben Decrop 2012 - 2015
# copyright Chessdevil Consulting BVBA 2015 - 2019

import logging
import uuid
import asyncio

from jose import JWTError, ExpiredSignatureError
from fastapi import BackgroundTasks
from fastapi.security import HTTPAuthorizationCredentials
from google.oauth2 import id_token
from google.auth.transport import requests
from datetime import datetime, timedelta
from typing import Optional, cast, List

from reddevil.core import (
    encode_model,
    get_settings,
    hash_password,
    jwt_encode,
    jwt_getunverifiedpayload,
    jwt_verify,
    verify_password,
    RdBadRequest,
    RdNotAuthorized,
    RdNotFound,
)
from reddevil.mail import sendEmailNoAttachments
from .md_account import (
    AccountDB,
    AccountInValidator,
    AccountLoginValidator,
    AccountOutDetailValidator,
    AccountOutValidator,
    AccountPasswordConfirmValidator,
    AccountPasswordResetValidator,
    AccountPasswordUpdateValidator,
    AccountUpdateValidator,
    LoginType,
    DbAccount,
)
from .md_accountrequest import (
    AccountRequest,
    AccountRequestType,
    AccountRequestVerification,
    DbAccountRequest,
)
from reddevil.mail import MailParams

logger = logging.getLogger(__name__)


async def get_accounts(options: dict = {}) -> List[AccountDB]:
    """
    get all account
    """
    validator = options.pop("_class", AccountOutValidator)
    return await DbAccount.p_find_multiple(options)


async def add_account(d: AccountInValidator, options={}) -> AccountDB:
    """
    add a new Account
    """
    acc = AccountDB(
        domain=d.domain,
        email=d.email,
        enabled=d.enabled,
        groups=[],
        hashed_password=d.password or None,
        id=d.id,
        locale=d.locale,
        logintype=d.logintype,
        tokensalt=str(uuid.uuid1()),
        verified=False,
    )
    return await DbAccount.add(acc, options)


async def delete_account(id: str) -> None:
    """
    delete the account
    """
    await DbAccount.delete(id)


async def get_account(options: dict = {}) -> AccountDB:
    """
    get the account, AccountOut is default validator
    """
    return await DbAccount.find_single(options)


async def update_account(
    id: str, d: AccountUpdateValidator, options: dict = {}
) -> dict:
    """
    update a Account
    """
    logger.debug(f"updating {id}")
    try:
        uacc = await DbAccount.update(id, d.model_dump(exclude_unset=True), options)
    except:
        logger.exception("cannot update account")
    logger.debug(f"updated {uacc['id']}")
    return uacc


async def add_accountrequest(d: AccountRequest, options={}) -> AccountRequest:
    """
    add a new AccountREquest
    """
    return await DbAccountRequest.p_add(d)


async def register_account(ai: AccountInValidator, bt: BackgroundTasks) -> AccountDB:
    """
    add a new Account
    """
    settings = get_settings()
    acc = await add_account(ai)
    ar = await add_accountrequest(
        AccountRequest(
            username=ai.id,
            expiry_time=datetime.utcnow()
            + timedelta(hours=settings.ACCOUNT["email_expiry_hours"]),
            reason="account_registration",
        )
    )
    mp = MailParams(
        bcc=settings.EMAIL.get("bcc"),
        locale=ai.locale,
        receiver=acc.email,
        sender=settings.EMAIL["sender"],
        subject="Account registration",
        template=settings.ACCOUNT["account_register_template"],
    )
    context = acc.dict()
    context.update(ar.dict())
    bt.add_task(sendEmailNoAttachments, mp, context, "account_registration")
    return acc


async def account_email_verification(arv: AccountRequestVerification) -> None:
    """
    verify returned email verification
    """
    ardict = await DbAccountRequest.find_single(
        {"id": arv.id, "username": arv.username}
    )
    ar = cast(AccountRequest, encode_model(ardict, AccountRequest))
    assert ar.expiry_time and ar.username
    if ar.reason != arv.reason:
        raise RdBadRequest(description="WrongReason")
    if ar.expiry_time < datetime.utcnow():
        raise RdBadRequest(description="VerificationRequestExpired")
    # the verification succeeded, drop the request and update the account
    await DbAccountRequest.delete(arv.id)
    hashed_password = hash_password(arv.password)
    await update_account(
        ar.username,
        AccountUpdateValidator(),
        {"$set": {"verified": True, "hashed_password": hashed_password}},
    )
    logger.info(
        f"AccountRequest {arv.reason} for {ar.username} successfully processed."
    )


async def update_password(apu: AccountPasswordUpdateValidator, checkold=True) -> None:
    """
    update password
    """
    try:
        acc = await get_account(
            apu.username,
            {"_class": AccountDB, "_fieldlist": ["hashed_password", "tokensalt"]},
        )
        assert acc.hashed_password
    except RdNotFound:
        raise RdNotAuthorized(description="WrongUsernamePasswordCombination")
    verified = verify_password(apu.oldpassword, acc.hashed_password)
    if checkold and not verified:
        raise RdNotAuthorized(description="WrongUsernamePasswordCombination")
    hashed_password = hash_password(apu.newpassword)
    await update_account(
        apu.username,
        AccountUpdateValidator(),
        {
            "$set": {
                "hashed_password": hashed_password,
            }
        },
    )
    logger.info(f"Account {apu.username} password changed.")


async def check_accountid(id: str) -> bool:
    """
    check if account id already exists
    """
    try:
        await DbAccount.find_single({"id": id})
        return True
    except RdNotFound:
        logger.debug("JWT Error")
        return False


async def confirm_passwordreset(pwc: AccountPasswordConfirmValidator) -> str:
    """
    confirms a newly reset password, returning a new authorisation token
    """
    settings = get_settings()
    hashed_password = hash_password(pwc.newpassword)
    await update_account(
        pwc.username,
        AccountUpdateValidator(),
        {"$set": {"hashed_password": hashed_password}},
    )
    acc = await get_account(
        pwc.username,
        {"_class": AccountDB, "_fieldlist": ["hashed_password", "tokensalt"]},
    )
    token = await get_token(acc, timedelta(minutes=settings.TOKEN["timeout"]))
    return token


async def get_token(acc: dict, duration: timedelta, invalidate: bool = True) -> str:
    """
    gets a new JWT token for a user
    :param acc: an Account
    :param invalidate: invalidate the existing tokens by changing the salt
    :return: return the newly created token
    """
    id = acc["id"]
    assert id
    if invalidate or acc["tokensalt"] is None:
        tokensalt = str(uuid.uuid1())
        logger.debug("get_token needs updating account with new tokensalt")
        await update_account(
            id, AccountUpdateValidator(), {"$set": {"tokensalt": tokensalt}}
        )
    else:
        tokensalt = acc["tokensalt"]
        await asyncio.sleep(0)  # a noop await
    payload = {"sub": acc["id"], "exp": datetime.utcnow() + duration}
    return jwt_encode(payload, tokensalt)


async def login(al: AccountLoginValidator) -> str:
    """
    login and returns a newly create JWT token
    """
    logger.debug("entering login")
    settings = get_settings()
    if al.logintype == "google":
        assert al.token is not None
        token = al.token
        try:
            idinfo = id_token.verify_oauth2_token(
                token, requests.Request(), settings.GOOGLE_CLIENT_ID
            )
        except ValueError:
            raise RdNotAuthorized(description="InvalidGoogleToken")
        if idinfo["iss"] not in ["accounts.google.com", "https://accounts.google.com"]:
            raise RdNotAuthorized(description="WrongAuthIssuer")
        if (
            settings.GOOGLE_LOGIN_DOMAINS
            and idinfo["hd"] not in settings.GOOGLE_LOGIN_DOMAINS
        ):
            raise RdNotAuthorized(description="WrongGoogleDomain")
        try:
            acc = await get_account(
                {"id": idinfo["email"], "_fieldlist": ["tokensalt"]}
            )
            logger.debug(f"found account {acc['id']}")
        except RdNotFound:
            logger.debug(f"account not found creating ...")
            ai = AccountInValidator(
                domain=idinfo["hd"],
                email=idinfo["email"],
                enabled=True,
                id=idinfo["email"],
                logintype="google",
            )
            acc = await DbAccount.add(ai, {"_fieldlist": ["id", "tokensalt"]})
    elif al.logintype == "email":
        assert al.password
        if al.username is None:
            raise RdBadRequest(description="MissingUsername")
        try:
            acc = await get_account(
                al.username,
                {"_fieldlist": ["hashed_password", "tokensalt"]},
            )
            assert acc["hashed_password"]
        except RdNotFound:
            raise RdNotAuthorized(description="WrongUserPasswordCombination")
        verified = False
        try:
            verified = verify_password(al.password, acc["hashed_password"])
        except Exception as e:
            logger.exception("cannot process verify password")
        if not verified:
            raise RdNotAuthorized(description="WrongUserPasswordCombination")
    else:
        raise RdBadRequest(description="InvalidLoginType")
    logger.info(f"logged in as {acc['id']}")
    token = await get_token(acc, timedelta(minutes=settings.TOKEN["timeout"]))
    return token
